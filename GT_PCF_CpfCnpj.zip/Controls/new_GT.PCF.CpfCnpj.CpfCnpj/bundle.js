var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./CpfCnpj/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./CpfCnpj/index.ts":
/*!**************************!*\
  !*** ./CpfCnpj/index.ts ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar CpfCnpj =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function CpfCnpj() {\n    this._value = \"\";\n  }\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  CpfCnpj.prototype.init = function (context, notifyOutputChanged, state, container) {\n    this._context = context;\n    this.input = document.createElement(\"input\");\n    this.input.setAttribute(\"type\", \"text\");\n    this.input.addEventListener(\"blur\", this.onInputBlur.bind(this));\n    this.input.addEventListener(\"keydown\", this.onInputKeyDown.bind(this));\n    this._notifyOutputChanged = notifyOutputChanged;\n    container.appendChild(this.input);\n  };\n\n  CpfCnpj.prototype.onInputBlur = function (event) {\n    var isValid = this.checkCPFCNPJ(this.input.value);\n\n    if (!isValid) {\n      this.input.value = \"\";\n      this._value = \"\";\n    }\n\n    this._notifyOutputChanged();\n  };\n\n  CpfCnpj.prototype.onInputKeyDown = function (event) {\n    var _this = this;\n\n    setTimeout(function () {\n      _this.fMascEx();\n    }, 1);\n  };\n\n  CpfCnpj.prototype.fMascEx = function () {\n    var fieldType = this._context.parameters.fieldType.raw.toLowerCase();\n\n    var isFieldTypeCPF = !fieldType || fieldType == \"\" || fieldType == \"cpf\";\n    this.input.setAttribute(\"maxlength\", isFieldTypeCPF ? \"14\" : \"18\");\n    if (isFieldTypeCPF) this._value = this.mCPF(this.input.value);else this._value = this.mCNPJ(this.input.value);\n\n    this._notifyOutputChanged();\n  };\n\n  CpfCnpj.prototype.mCPF = function (cpf) {\n    cpf = cpf.replace(/\\D/g, \"\");\n    cpf = cpf.replace(/(\\d{3})(\\d)/, \"$1.$2\");\n    cpf = cpf.replace(/(\\d{3})(\\d)/, \"$1.$2\");\n    cpf = cpf.replace(/(\\d{3})(\\d{1,2})$/, \"$1-$2\");\n    return cpf;\n  };\n\n  CpfCnpj.prototype.mCNPJ = function (cnpj) {\n    cnpj = cnpj.replace(/\\D/g, \"\");\n    cnpj = cnpj.replace(/^(\\d{2})(\\d)/, \"$1.$2\");\n    cnpj = cnpj.replace(/^(\\d{2})\\.(\\d{3})(\\d)/, \"$1.$2.$3\");\n    cnpj = cnpj.replace(/\\.(\\d{3})(\\d)/, \".$1/$2\");\n    cnpj = cnpj.replace(/(\\d{4})(\\d)/, \"$1-$2\");\n    return cnpj;\n  };\n\n  CpfCnpj.prototype.checkCPFCNPJ = function (txt) {\n    var isValid = true;\n    var msgError = \"\";\n    var txtContent = txt.replace(/\\./g, \"\").replace(\"-\", \"\").replace(\"/\", \"\").trim();\n    if (txtContent == \"\") return true;\n\n    if (txtContent.length == 14) {\n      isValid = this.IsCNPJ(txtContent);\n      if (!isValid) msgError = \"CNPJ Inválido\";\n    } else {\n      isValid = this.IsCPF(txtContent);\n      if (!isValid) msgError = \"CPF Inválido\";\n    }\n\n    if (msgError != \"\") {\n      this._context.navigation.openAlertDialog({\n        confirmButtonLabel: \"OK\",\n        text: msgError\n      });\n    }\n\n    return isValid;\n  };\n\n  CpfCnpj.prototype.IsCNPJ = function (cnpj) {\n    cnpj = cnpj.replace(/[^\\d]+/g, '');\n    if (cnpj == '') return false;\n    if (cnpj.length != 14) return false; // Elimina CNPJs invalidos conhecidos\n\n    if (cnpj == \"00000000000000\" || cnpj == \"11111111111111\" || cnpj == \"22222222222222\" || cnpj == \"33333333333333\" || cnpj == \"44444444444444\" || cnpj == \"55555555555555\" || cnpj == \"66666666666666\" || cnpj == \"77777777777777\" || cnpj == \"88888888888888\" || cnpj == \"99999999999999\") return false; // Valida DVs\n\n    var tamanho;\n    var numeros;\n    var digitos;\n    var soma;\n    tamanho = cnpj.length - 2;\n    numeros = cnpj.substring(0, tamanho);\n    digitos = cnpj.substring(tamanho);\n    soma = 0;\n    var pos = tamanho - 7;\n\n    for (var i = tamanho; i >= 1; i--) {\n      soma += numeros.charAt(tamanho - i) * pos--;\n      if (pos < 2) pos = 9;\n    }\n\n    var resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;\n    if (resultado != digitos.charAt(0)) return false;\n    tamanho = tamanho + 1;\n    numeros = cnpj.substring(0, tamanho);\n    soma = 0;\n    pos = tamanho - 7;\n\n    for (i = tamanho; i >= 1; i--) {\n      soma += numeros.charAt(tamanho - i) * pos--;\n      if (pos < 2) pos = 9;\n    }\n\n    resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;\n    if (resultado != digitos.charAt(1)) return false;\n    return true;\n  };\n\n  CpfCnpj.prototype.IsCPF = function (strCPF) {\n    var Soma;\n    var Resto;\n    Soma = 0; // Elimina CPFs invalidos conhecidos\n\n    if (strCPF == \"00000000000\" || strCPF == \"11111111111\" || strCPF == \"22222222222\" || strCPF == \"33333333333\" || strCPF == \"44444444444\" || strCPF == \"55555555555\" || strCPF == \"66666666666\" || strCPF == \"77777777777\" || strCPF == \"88888888888\" || strCPF == \"99999999999\") return false;\n\n    for (var i = 1; i <= 9; i++) Soma = Soma + parseInt(strCPF.substring(i - 1, i)) * (11 - i);\n\n    Resto = Soma * 10 % 11;\n    if (Resto == 10 || Resto == 11) Resto = 0;\n    if (Resto != parseInt(strCPF.substring(9, 10))) return false;\n    Soma = 0;\n\n    for (var i = 1; i <= 10; i++) Soma = Soma + parseInt(strCPF.substring(i - 1, i)) * (12 - i);\n\n    Resto = Soma * 10 % 11;\n    if (Resto == 10 || Resto == 11) Resto = 0;\n    if (Resto != parseInt(strCPF.substring(10, 11))) return false;\n    return true;\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  CpfCnpj.prototype.updateView = function (context) {\n    // Add code to update control view\n    this._value = context.parameters.cpfcnpjValue.raw;\n    this.input.value = this._value != null ? this._value : \"\";\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  CpfCnpj.prototype.getOutputs = function () {\n    return {\n      cpfcnpjValue: this._value\n    };\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  CpfCnpj.prototype.destroy = function () {// Add code to cleanup control if necessary\n  };\n\n  return CpfCnpj;\n}();\n\nexports.CpfCnpj = CpfCnpj;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./CpfCnpj/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('GT.PCF.CpfCnpj.CpfCnpj', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.CpfCnpj);
} else {
	var GT = GT || {};
	GT.PCF = GT.PCF || {};
	GT.PCF.CpfCnpj = GT.PCF.CpfCnpj || {};
	GT.PCF.CpfCnpj.CpfCnpj = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.CpfCnpj;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}